<?php
	echo phpversion();
?>