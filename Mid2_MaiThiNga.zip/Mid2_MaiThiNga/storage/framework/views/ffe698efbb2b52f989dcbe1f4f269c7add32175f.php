<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
	<style>
		td, th {
		  	border: 1px solid #dddddd;
		  	text-align: left;
		  	padding: 8px;
		}
		th{
			
			background-color: orange;
		}
		img{
			width: 100px;
			height: 100px;
		}
		.action{
			display: flex;
		}
	</style>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

</head>
<body>
	<a href="admin/insert">
		<button class="btn btn-info">
			<i class="fas fa-plus-circle"> ADD</i>
		</button>
	</a>
	<center>
		<table>
			<tr>
				<th>ID</th>
				<th>Name Product</th>
				<th class="image">Image</th>
				<th>Description</th>
				<th>Unit Price</th>
				<th>Promotion Price</th>
				<th>Unit</th>
				<th>Action</th>
			</tr>
			<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo $products['id']; ?></td>
					<td><?php echo $products['name']; ?></td>
					<td><img src="source/image/product/<?php echo e($products->image); ?>"></td>
					<td><?php echo $products['description']; ?></td>
					<td><?php echo $products['unit_price']; ?></td>
					<td><?php echo $products['promotion_price']; ?></td>
					<td><?php echo $products['unit']; ?></td>
					<td class="action">
						<a href="admin/edit/<?php echo $products['id']; ?>">
							<button class="btn btn-warning" name="edit" value="<?php echo $products['id']; ?>"><i class="fas fa-edit"></i></button>
						</a>
						<a href="admin/delete/<?php echo $products['id']; ?>">
							<button class="btn btn-danger" name="delete" value="<?php echo $products['id']; ?>"><i class="fas fa-trash"></i></button>
						</a>
					</td>
				</tr>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel2\Mid2_MaiThiNga\resources\views/admin/admin.blade.php ENDPATH**/ ?>