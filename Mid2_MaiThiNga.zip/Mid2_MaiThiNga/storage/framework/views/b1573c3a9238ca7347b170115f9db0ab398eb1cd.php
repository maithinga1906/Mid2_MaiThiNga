<!DOCTYPE html>
<html>
<head>
	<title>insert</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
	<style type="text/css">
		form{
			width: 500px;
		}
	</style>
</head>
<body>
	<a href="admin"><-</a>
	<center>
		<form method="post" enctype="multipart/form-data">
			<?php echo csrf_field(); ?>
		    <br>
		    <input type="" class="form-control" placeholder="Name Product" name="name">
		    <br>
		    <select name="type">
		    	<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $types): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    	<option  value="<?php echo $types->id; ?>"><?php echo $types->name; ?></option>
		    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </select>
		    <br>
		     <input type="" class="form-control" placeholder="Description" name="description">
		    <br>
		     <input type="" class="form-control" placeholder="Unit Price" name="unit_price">
		    <br>
		     <input type="" class="form-control" placeholder="Promotion Price" name="promotion_price">
		    <br>
		    <input type="file" name="myFile" id="myFile">
	    	<br>
	    	<input type="" class="form-control" placeholder="Unit" name="unit">
		    <br>
		    <input type="" class="form-control" placeholder="New " name="new">
		    <br>
		    <button type="submit" class="btn btn-success" name="sub">Submit</button>
		</form>
		
	</center>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel2\project\resources\views/admin/insertProduct.blade.php ENDPATH**/ ?>